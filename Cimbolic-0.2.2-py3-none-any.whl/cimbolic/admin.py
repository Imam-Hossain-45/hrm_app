from django.contrib import admin

from .models import Variable, Formula

admin.site.register(Variable)
admin.site.register(Formula)
